"use client";

import React from "react";
import { Clock, MapPin, Phone } from "lucide-react";
import { CAFE_INFO } from "@/data/menu";

export const AnnouncementStrip: React.FC = () => {
  return (
    <div className="bg-saffron text-midnight py-2 px-4 text-xs sm:text-sm font-sans font-medium tracking-wide">
      <div className="container max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-4 flex-wrap mx-auto sm:mx-0">
          <div className="flex items-center gap-1.5 font-bold">
            <Clock className="w-3.5 h-3.5" />
            <span>Open Today: {CAFE_INFO.openingHours}</span>
          </div>
          <span className="hidden md:inline opacity-40">|</span>
          <div className="hidden md:flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" />
            <span>{CAFE_INFO.fullAddress}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 mx-auto sm:mx-0 font-semibold">
          <a
            href={CAFE_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 hover:underline"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>WhatsApp: {CAFE_INFO.phone}</span>
          </a>
        </div>
      </div>
    </div>
  );
};
