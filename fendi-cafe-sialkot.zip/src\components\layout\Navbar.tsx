"use client";

import React, { useState, useEffect } from "react";
import { ShoppingBag, Menu as MenuIcon, X, Phone } from "lucide-react";
import { FendiLogo } from "@/components/ui/FendiLogo";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { useCartStore } from "@/store/useCartStore";
import { useIsMounted } from "@/hooks/useIsMounted";
import { CAFE_INFO } from "@/data/menu";

const NAV_LINKS = [
  { id: "hero", label: "Home" },
  { id: "menu", label: "Menu" },
  { id: "story", label: "Our Story" },
  { id: "reviews", label: "Reviews" },
  { id: "location", label: "Location & Hours" },
];

export const Navbar: React.FC = () => {
  const isMounted = useIsMounted();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");

  const totalItems = useCartStore((state) => (isMounted ? state.getTotalItems() : 0));
  const openCart = useCartStore((state) => state.openCart);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
  }, [isMobileMenuOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIsMobileMenuOpen(false);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false);
    setActiveSection(id);
    if (id === "hero") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? "bg-midnight/90 backdrop-blur-md border-b border-midnight-border py-3 shadow-xl"
          : "bg-transparent py-5"
      }`}
    >
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo */}
          <button
            onClick={() => scrollToSection("hero")}
            className="text-left focus:outline-none focus:ring-2 focus:ring-saffron/50 rounded-lg p-1"
          >
            <FendiLogo size="md" />
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-8" aria-label="Main Navigation">
            {NAV_LINKS.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className={`text-sm font-sans font-medium transition-colors relative py-1 focus:outline-none focus:ring-1 focus:ring-saffron rounded ${
                  activeSection === link.id
                    ? "text-saffron font-semibold"
                    : "text-ivory-muted hover:text-ivory"
                }`}
              >
                {link.label}
                {activeSection === link.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-saffron rounded-full animate-pulse" />
                )}
              </button>
            ))}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-3">
            
            {/* Dark / Light Theme Toggle */}
            <ThemeToggle />

            {/* Direct WhatsApp Call */}
            <a
              href={CAFE_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-2 text-xs font-mono tracking-wider text-saffron bg-saffron/10 border border-saffron/30 px-3 py-2 rounded-lg hover:bg-saffron/20 transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>

            {/* Cart Trigger */}
            <button
              onClick={openCart}
              aria-label={`Shopping cart with ${totalItems} items`}
              className="relative p-2.5 rounded-xl bg-midnight-card border border-midnight-border text-ivory hover:border-saffron/50 hover:bg-midnight-elevated transition-all active:scale-95 focus:outline-none focus:ring-2 focus:ring-saffron"
            >
              <ShoppingBag className="w-5 h-5 text-saffron" />
              {isMounted && totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-saffron text-midnight font-bold font-mono text-[11px] w-5 h-5 rounded-full flex items-center justify-center shadow-saffron-glow animate-bounce">
                  {totalItems}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
              className="lg:hidden p-2.5 rounded-xl bg-midnight-card border border-midnight-border text-ivory hover:border-saffron/50 transition-colors focus:outline-none focus:ring-2 focus:ring-saffron"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6 text-saffron" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-[70px] z-50 bg-midnight/98 backdrop-blur-xl flex flex-col justify-between p-6 border-t border-midnight-border animate-in slide-in-from-top duration-300">
          <div className="space-y-6 pt-4">
            
            <div className="flex items-center justify-between border-b border-midnight-border/50 pb-4">
              <span className="text-xs font-mono uppercase text-ivory-subtle">Appearance</span>
              <ThemeToggle />
            </div>

            <nav className="flex flex-col gap-3">
              {NAV_LINKS.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="text-left font-serif text-2xl font-bold text-ivory hover:text-saffron py-2 border-b border-midnight-border/50 transition-colors flex items-center justify-between"
                >
                  <span>{link.label}</span>
                  <span className="text-saffron font-mono text-sm">→</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="space-y-4 pb-8">
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                openCart();
              }}
              className="w-full py-4 rounded-xl bg-saffron text-midnight font-bold font-sans text-center flex items-center justify-center gap-2 shadow-saffron-glow"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>View Cart ({totalItems} items)</span>
            </button>

            <a
              href={CAFE_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 rounded-xl bg-midnight-card border border-saffron/40 text-saffron text-center font-medium font-sans flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4" />
              <span>WhatsApp Direct Order</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
