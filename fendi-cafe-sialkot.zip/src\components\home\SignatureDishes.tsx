"use client";

import React, { useState } from "react";
import { Plus, Check, Flame } from "lucide-react";
import { useCartStore } from "@/store/useCartStore";
import { useMenuStore } from "@/store/useMenuStore";
import { useIsMounted } from "@/hooks/useIsMounted";
import { MENU_ITEMS } from "@/data/menu";

export const SignatureDishes: React.FC = () => {
  const isMounted = useIsMounted();
  const storeItems = useMenuStore((state) => state.items);
  const addItem = useCartStore((state) => state.addItem);
  const [addedId, setAddedId] = useState<string | null>(null);

  const menuItems = isMounted ? storeItems : MENU_ITEMS;

  const signatureItems = menuItems.filter(
    (item) => item.isPopular || ["brg-thunder", "shw-fendi-platter", "deal-sd2", "deal-bd1"].includes(item.id)
  ).slice(0, 4);

  const handleQuickAdd = (item: typeof signatureItems[0]) => {
    addItem(item, 1);
    setAddedId(item.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  return (
    <section className="py-20 bg-midnight relative">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 border-b border-midnight-border pb-6">
          <div className="space-y-2">
            <span className="text-xs font-mono uppercase tracking-widest text-saffron">
              Sialkot's Most Requested
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-ivory">
              Signature Favourites
            </h2>
          </div>
          <p className="text-sm text-ivory-muted max-w-md mt-4 md:mt-0 font-sans">
            Handcrafted with intense spices, juicy tender cuts, and signature sauces loved across Circular Road.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {signatureItems.map((item) => {
            const isJustAdded = addedId === item.id;

            return (
              <div
                key={item.id}
                className="group relative bg-midnight-card border border-midnight-border hover:border-saffron/40 rounded-2xl p-6 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 shadow-card-subtle"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="inline-flex items-center gap-1 text-[11px] font-mono tracking-wider text-saffron bg-saffron/10 px-2.5 py-1 rounded-md border border-saffron/20">
                      <Flame className="w-3 h-3" />
                      <span>SIGNATURE</span>
                    </span>
                    <span className="text-xs font-mono text-ivory-subtle">RS {item.price}</span>
                  </div>

                  <h3 className="font-serif text-xl font-bold text-ivory mb-2 group-hover:text-saffron transition-colors">
                    {item.name}
                  </h3>

                  {item.description && (
                    <p className="text-xs text-ivory-muted leading-relaxed line-clamp-3 mb-6 font-sans">
                      {item.description}
                    </p>
                  )}
                </div>

                <div className="pt-4 border-t border-midnight-border/60 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-mono text-ivory-subtle block">Price</span>
                    <span className="font-serif text-lg font-bold text-saffron">
                      PKR {item.price.toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => handleQuickAdd(item)}
                    className={`px-4 py-2.5 rounded-xl font-sans text-xs font-bold transition-all flex items-center gap-1.5 ${
                      isJustAdded
                        ? "bg-emerald-500 text-white"
                        : "bg-saffron text-midnight hover:bg-saffron-light active:scale-95 shadow-saffron-glow"
                    }`}
                  >
                    {isJustAdded ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Added</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
