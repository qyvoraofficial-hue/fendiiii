export type CategoryId =
  | "all"
  | "appetizers"
  | "burgers"
  | "shawarma-wraps"
  | "shawarma-deals"
  | "burger-deals"
  | "combos"
  | "drinks";

export interface MenuItem {
  id: string;
  name: string;
  category: CategoryId;
  price: number;
  description?: string;
  image?: string;
  isPopular?: boolean;
  isSoldOut?: boolean;
}

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
}

export type OrderType = "takeaway" | "delivery";

export interface TakeawayDetails {
  name: string;
  phone: string;
  pickupTime: string;
  note?: string;
}

export interface DeliveryDetails {
  name: string;
  phone: string;
  address: string;
  area: string;
  landmark: string;
  note?: string;
}

export interface OrderState {
  orderType: OrderType;
  takeaway: TakeawayDetails;
  delivery: DeliveryDetails;
}
