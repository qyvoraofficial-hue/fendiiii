"use client";

import React from "react";
import { MessageSquare, ArrowRight, Clock } from "lucide-react";
import { CAFE_INFO } from "@/data/menu";

export const WhatsAppCtaBanner: React.FC = () => {
  return (
    <section className="py-16 bg-midnight relative overflow-hidden">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="bg-gradient-to-r from-midnight-card via-midnight-elevated to-midnight-card border border-saffron/30 rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-2xl flex flex-col md:flex-row items-center justify-between gap-8">
          
          {/* Ambient Glow */}
          <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-saffron/15 rounded-full blur-3xl pointer-events-none" />

          <div className="space-y-4 max-w-xl text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-saffron/10 border border-saffron/30 text-saffron font-mono text-xs uppercase tracking-wider">
              <Clock className="w-3.5 h-3.5" />
              <span>Late Night Orders Open Now</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-ivory">
              Craving Fresh Burgers or Shawarma Right Now?
            </h2>

            <p className="text-sm text-ivory-muted font-sans">
              Send your order directly to our Circular Road kitchen on WhatsApp. Fast dispatch, honest charges, and instant response.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
            <a
              href={CAFE_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-saffron text-midnight font-bold font-sans tracking-wide hover:bg-saffron-light active:scale-95 transition-all shadow-saffron-glow flex items-center justify-center gap-2 text-sm group whitespace-nowrap"
            >
              <MessageSquare className="w-5 h-5" />
              <span>Order via WhatsApp</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>

        </div>

      </div>
    </section>
  );
};
