"use client";

import React, { useState, useEffect } from "react";
import { motion, useMotionValue, useSpring, useScroll, useTransform, useReducedMotion } from "framer-motion";
import { ArrowRight, ShoppingBag, Clock, MapPin, Truck } from "lucide-react";
import { useCartStore } from "@/store/useCartStore";

// The 9 vertical burger layers
const BURGER_LAYERS = [
  { id: "top-bun", name: "Artisanal Sesame Top Bun", zIndex: 9 },
  { id: "top-sauce", name: "Signature Secret Sauce Drizzle", zIndex: 8 },
  { id: "lettuce", name: "Crispy Iceberg Lettuce", zIndex: 7 },
  { id: "tomato", name: "Fresh Sliced Tomatoes", zIndex: 6 },
  { id: "cheese", name: "Melted Aged Cheddar", zIndex: 5 },
  { id: "patty", name: "Crispy Golden Zinger Fillet", zIndex: 4 },
  { id: "onion", name: "Caramelized Red Onions", zIndex: 3 },
  { id: "bottom-sauce", name: "Garlic Mayo Spread", zIndex: 2 },
  { id: "bottom-bun", name: "Toasted Brioche Base", zIndex: 1 },
];

export const ExplodedBurgerHero: React.FC = () => {
  const [isHovered, setIsHovered] = useState(false);
  const shouldReduceMotion = useReducedMotion();
  const openCart = useCartStore((state) => state.openCart);

  // Smooth Motion Values for mouse parallax WITHOUT triggering React re-renders!
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);

  // Smooth spring physics for fluid movement
  const springX = useSpring(rawX, { stiffness: 100, damping: 20 });
  const springY = useSpring(rawY, { stiffness: 100, damping: 20 });

  const { scrollY } = useScroll();
  const scrollYShift = useTransform(scrollY, [0, 400], [0, 40]);

  useEffect(() => {
    if (shouldReduceMotion) return;

    let animationFrameId: number;
    const handleMouseMove = (e: MouseEvent) => {
      // Throttle calculation to animation frame for maximum smoothness
      animationFrameId = requestAnimationFrame(() => {
        const { innerWidth, innerHeight } = window;
        const offsetX = (e.clientX / innerWidth - 0.5) * 24;
        const offsetY = (e.clientY / innerHeight - 0.5) * 24;
        rawX.set(offsetX);
        rawY.set(offsetY);
      });
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
    };
  }, [rawX, rawY, shouldReduceMotion]);

  const scrollToMenu = () => {
    const menuElement = document.getElementById("menu");
    if (menuElement) {
      menuElement.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-[92vh] flex items-center justify-center pt-28 pb-16 overflow-hidden bg-midnight bg-radial-hero">
      {/* Background ambient lighting */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-saffron/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-10 left-10 w-[300px] h-[300px] bg-paprika/10 rounded-full blur-[100px] pointer-events-none" />
      </div>

      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* LEFT: Hero Copy */}
          <div className="lg:col-span-6 text-center lg:text-left space-y-6">
            
            {/* Eyebrow */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-saffron/30 bg-saffron/10 backdrop-blur-sm"
            >
              <span className="w-2 h-2 rounded-full bg-saffron animate-pulse" />
              <span className="text-xs sm:text-sm font-mono tracking-wider text-saffron uppercase font-medium">
                Sialkot’s Late-Night Flavour Spot
              </span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-serif text-4xl sm:text-6xl xl:text-7xl font-bold tracking-tight text-ivory leading-[1.08]"
            >
              Fresh. Loaded. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-saffron-light via-saffron to-saffron-dark">
                Worth the craving.
              </span>
            </motion.h1>

            {/* Supporting Copy */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-base sm:text-lg text-ivory-muted max-w-xl mx-auto lg:mx-0 font-sans leading-relaxed"
            >
              Flavour-packed shawarmas, juicy burgers, loaded fries and sharing favourites—prepared fresh for serious cravings.
            </motion.p>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2"
            >
              <button
                onClick={openCart}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-saffron text-midnight font-bold font-sans tracking-wide hover:bg-saffron-light active:scale-95 transition-all shadow-saffron-glow flex items-center justify-center gap-2 group"
              >
                <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <span>Order Now</span>
              </button>

              <button
                onClick={scrollToMenu}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-midnight-card border border-midnight-border text-ivory font-medium font-sans hover:bg-midnight-elevated hover:border-saffron/40 active:scale-95 transition-all flex items-center justify-center gap-2 group"
              >
                <span>Explore Menu</span>
                <ArrowRight className="w-4 h-4 text-saffron group-hover:translate-x-1 transition-transform" />
              </button>
            </motion.div>

            {/* Trust Line Strip */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="pt-6 border-t border-midnight-border flex flex-wrap items-center justify-center lg:justify-start gap-x-6 gap-y-2 text-xs sm:text-sm text-ivory-subtle"
            >
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-saffron" />
                <span>Open 2:00 PM – 2:00 AM</span>
              </div>
              <span className="hidden sm:inline text-midnight-border">•</span>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-saffron" />
                <span>Circular Road, Sialkot</span>
              </div>
              <span className="hidden sm:inline text-midnight-border">•</span>
              <div className="flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-saffron" />
                <span>Takeaway & Delivery</span>
              </div>
            </motion.div>

          </div>

          {/* RIGHT: Exploded Burger Hardware Accelerated Canvas */}
          <div className="lg:col-span-6 flex justify-center items-center py-4 relative">
            <motion.div
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
              style={
                shouldReduceMotion
                  ? { y: scrollYShift }
                  : {
                      x: springX,
                      y: springY,
                    }
              }
              className="relative w-full max-w-[340px] sm:max-w-[420px] h-[480px] sm:h-[540px] flex flex-col items-center justify-center cursor-pointer group select-none gpu-accelerated"
            >
              {/* Radial Glow */}
              <div className="absolute inset-0 bg-saffron/15 rounded-full blur-3xl opacity-60 group-hover:opacity-90 transition-opacity pointer-events-none" />

              {/* 9 Burger Layers Container */}
              <div className="relative w-full h-full flex flex-col items-center justify-center">
                {BURGER_LAYERS.map((layer, index) => {
                  const expandedGap = isHovered ? "6px" : "18px";

                  return (
                    <motion.div
                      key={layer.id}
                      initial={
                        shouldReduceMotion
                          ? { opacity: 1 }
                          : { opacity: 0, y: (index - 4) * 30 }
                      }
                      animate={{
                        opacity: 1,
                        y: 0,
                      }}
                      transition={{
                        duration: 0.6,
                        delay: 0.06 * index,
                        ease: "easeOut",
                      }}
                      className="relative w-full flex items-center justify-center transition-all duration-300 gpu-accelerated"
                      style={{
                        zIndex: layer.zIndex,
                        marginTop: index === 0 ? "0px" : expandedGap,
                      }}
                    >
                      <BurgerLayerVisual layerId={layer.id} />
                      
                      {/* Layer Tag on Desktop Hover */}
                      <span className="absolute right-0 sm:-right-6 text-[10px] sm:text-xs font-mono uppercase tracking-wider text-saffron bg-midnight-card/90 px-2 py-0.5 rounded border border-saffron/30 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-md hidden sm:inline-block">
                        {layer.name}
                      </span>
                    </motion.div>
                  );
                })}
              </div>

              {/* Hint pill */}
              <div className="absolute -bottom-2 bg-midnight-card/80 backdrop-blur-md px-3 py-1 rounded-full border border-midnight-border text-[11px] font-mono text-ivory-subtle shadow-md">
                Hover / Touch to Compress Layers
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
};

// Optimized Vector Graphics renderer for the 9 distinct layer graphics
const BurgerLayerVisual: React.FC<{ layerId: string }> = React.memo(({ layerId }) => {
  switch (layerId) {
    case "top-bun":
      return (
        <svg viewBox="0 0 320 90" className="w-[240px] sm:w-[300px] drop-shadow-[0_12px_12px_rgba(0,0,0,0.5)] gpu-accelerated">
          <defs>
            <linearGradient id="topBunGrad" x1="160" y1="5" x2="160" y2="85">
              <stop offset="0%" stopColor="#E69536" />
              <stop offset="60%" stopColor="#C4731E" />
              <stop offset="100%" stopColor="#8C4909" />
            </linearGradient>
          </defs>

          <path d="M 20,75 C 20,18 100,5 160,5 C 220,5 300,18 300,75 C 300,85 20,85 20,75 Z" fill="url(#topBunGrad)" />

          {/* Sesame Seeds */}
          <ellipse cx="100" cy="28" rx="4" ry="2" fill="#FFF3D6" transform="rotate(-15 100 28)" />
          <ellipse cx="140" cy="20" rx="4" ry="2" fill="#FFF3D6" transform="rotate(5 140 20)" />
          <ellipse cx="180" cy="23" rx="4" ry="2" fill="#FFF3D6" transform="rotate(-10 180 23)" />
          <ellipse cx="220" cy="32" rx="4" ry="2" fill="#FFF3D6" transform="rotate(20 220 32)" />
          <ellipse cx="70" cy="46" rx="4" ry="2" fill="#FFF3D6" transform="rotate(-25 70 46)" />
          <ellipse cx="250" cy="50" rx="4" ry="2" fill="#FFF3D6" transform="rotate(15 250 50)" />
          <ellipse cx="160" cy="40" rx="4" ry="2" fill="#FFF3D6" />

          {/* Toasted Gloss */}
          <path d="M 60,30 C 100,16 200,16 250,32 C 210,22 110,22 60,30 Z" fill="#FFC264" opacity="0.4" />
        </svg>
      );

    case "top-sauce":
      return (
        <svg viewBox="0 0 300 24" className="w-[220px] sm:w-[270px] drop-shadow-[0_4px_6px_rgba(0,0,0,0.4)] gpu-accelerated">
          <path d="M 20,12 Q 60,24 100,10 T 180,20 T 260,8 T 280,16" stroke="#FFC264" strokeWidth="7" fill="none" strokeLinecap="round" />
          <path d="M 40,6 Q 90,18 140,6 T 220,14" stroke="#E39A32" strokeWidth="5" fill="none" strokeLinecap="round" />
        </svg>
      );

    case "lettuce":
      return (
        <svg viewBox="0 0 340 40" className="w-[260px] sm:w-[320px] drop-shadow-[0_6px_10px_rgba(0,0,0,0.4)] gpu-accelerated">
          <path
            d="M 10,18 C 30,5 50,30 70,12 C 90,35 120,8 150,30 C 180,5 210,35 240,12 C 270,30 300,8 330,22 C 310,40 30,40 10,18 Z"
            fill="#48BB78"
          />
          <path
            d="M 20,20 C 40,8 60,28 80,15 C 100,32 130,12 160,28 M 200,10 C 230,30 260,12 290,26"
            stroke="#2F855A"
            strokeWidth="2.5"
            fill="none"
          />
        </svg>
      );

    case "tomato":
      return (
        <svg viewBox="0 0 310 30" className="w-[230px] sm:w-[280px] drop-shadow-[0_5px_8px_rgba(0,0,0,0.4)] gpu-accelerated">
          <ellipse cx="90" cy="15" rx="55" ry="10" fill="#E53E3E" />
          <ellipse cx="90" cy="15" rx="40" ry="7" fill="#C53030" />
          <ellipse cx="220" cy="15" rx="55" ry="10" fill="#E53E3E" />
          <ellipse cx="220" cy="15" rx="40" ry="7" fill="#C53030" />
        </svg>
      );

    case "cheese":
      return (
        <svg viewBox="0 0 320 35" className="w-[240px] sm:w-[290px] drop-shadow-[0_6px_10px_rgba(0,0,0,0.5)] gpu-accelerated">
          <path
            d="M 20,8 L 300,8 L 280,30 L 240,12 L 200,34 L 150,12 L 110,28 L 60,10 L 20,8 Z"
            fill="#F6AD55"
          />
        </svg>
      );

    case "patty":
      return (
        <svg viewBox="0 0 330 55" className="w-[250px] sm:w-[310px] drop-shadow-[0_10px_15px_rgba(0,0,0,0.6)] gpu-accelerated">
          <defs>
            <linearGradient id="pattyGrad" x1="165" y1="5" x2="165" y2="50">
              <stop offset="0%" stopColor="#A0522D" />
              <stop offset="50%" stopColor="#69351C" />
              <stop offset="100%" stopColor="#3D1E10" />
            </linearGradient>
          </defs>

          <rect x="15" y="6" width="300" height="42" rx="16" fill="url(#pattyGrad)" />
          <circle cx="40" cy="18" r="7" fill="#8B4513" />
          <circle cx="80" cy="30" r="9" fill="#D2691E" />
          <circle cx="130" cy="16" r="8" fill="#8B4513" />
          <circle cx="180" cy="34" r="10" fill="#CD853F" />
          <circle cx="230" cy="20" r="9" fill="#8B4513" />
          <circle cx="280" cy="28" r="7" fill="#D2691E" />
        </svg>
      );

    case "onion":
      return (
        <svg viewBox="0 0 290 24" className="w-[210px] sm:w-[260px] drop-shadow-[0_4px_6px_rgba(0,0,0,0.4)] gpu-accelerated">
          <ellipse cx="80" cy="12" rx="40" ry="7" stroke="#9F7AEA" strokeWidth="4.5" fill="none" />
          <ellipse cx="160" cy="12" rx="50" ry="8" stroke="#B794F4" strokeWidth="4.5" fill="none" />
          <ellipse cx="230" cy="12" rx="35" ry="6" stroke="#9F7AEA" strokeWidth="4.5" fill="none" />
        </svg>
      );

    case "bottom-sauce":
      return (
        <svg viewBox="0 0 280 20" className="w-[200px] sm:w-[250px] drop-shadow-[0_3px_5px_rgba(0,0,0,0.3)] gpu-accelerated">
          <path d="M 30,10 Q 90,20 150,8 T 250,15" stroke="#FFF9F0" strokeWidth="6" fill="none" strokeLinecap="round" opacity="0.9" />
        </svg>
      );

    case "bottom-bun":
      return (
        <svg viewBox="0 0 310 45" className="w-[230px] sm:w-[280px] drop-shadow-[0_10px_14px_rgba(0,0,0,0.5)] gpu-accelerated">
          <defs>
            <linearGradient id="bottomBunGrad" x1="155" y1="5" x2="155" y2="40">
              <stop offset="0%" stopColor="#D9822B" />
              <stop offset="100%" stopColor="#8C4909" />
            </linearGradient>
          </defs>
          <rect x="15" y="5" width="280" height="34" rx="12" fill="url(#bottomBunGrad)" />
          <line x1="25" y1="10" x2="285" y2="10" stroke="#FFC264" strokeWidth="2.5" opacity="0.5" />
        </svg>
      );

    default:
      return null;
  }
});

BurgerLayerVisual.displayName = "BurgerLayerVisual";
