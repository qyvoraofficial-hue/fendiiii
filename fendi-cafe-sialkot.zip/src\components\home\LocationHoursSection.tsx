"use client";

import React from "react";
import { MapPin, Clock, Phone, Navigation, MessageSquare, ExternalLink } from "lucide-react";
import { CAFE_INFO } from "@/data/menu";

export const LocationHoursSection: React.FC = () => {
  return (
    <section id="location" className="py-24 bg-midnight-secondary relative border-t border-midnight-border">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* LEFT: Details & Contacts */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-saffron">
                Visit & Contact Us
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-ivory mt-2">
                Location & Hours
              </h2>
              <p className="text-sm text-ivory-muted mt-3 font-sans">
                Located right on Circular Road in Sialkot. Easy access for walk-in takeaways or swift WhatsApp delivery dispatches.
              </p>
            </div>

            <div className="space-y-6">
              
              {/* Address Item */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-saffron/10 border border-saffron/30 flex items-center justify-center text-saffron flex-shrink-0 mt-1">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-ivory text-base">Address</h3>
                  <p className="text-xs sm:text-sm text-ivory-muted mt-1 leading-relaxed">
                    {CAFE_INFO.fullAddress}
                  </p>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(CAFE_INFO.googleMapsQuery)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-mono text-saffron hover:underline mt-2"
                  >
                    <span>Get Directions on Google Maps</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Operating Hours Item */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-saffron/10 border border-saffron/30 flex items-center justify-center text-saffron flex-shrink-0 mt-1">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-ivory text-base">Opening Hours</h3>
                  <p className="text-xs sm:text-sm text-ivory-muted mt-1">
                    {CAFE_INFO.openingHours}
                  </p>
                  <span className="inline-block text-[11px] font-mono text-saffron bg-saffron/10 px-2 py-0.5 rounded border border-saffron/20 mt-2">
                    7 Days a Week • Late-Night Service
                  </span>
                </div>
              </div>

              {/* Phone & WhatsApp Item */}
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-saffron/10 border border-saffron/30 flex items-center justify-center text-saffron flex-shrink-0 mt-1">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-ivory text-base">Phone & WhatsApp</h3>
                  <div className="space-y-1 mt-1 text-xs sm:text-sm text-ivory-muted">
                    <p>Mobile / WhatsApp: <strong className="text-ivory">{CAFE_INFO.phone}</strong></p>
                    <p>Landline: <strong className="text-ivory">{CAFE_INFO.secondaryPhone}</strong></p>
                  </div>
                  <a
                    href={CAFE_INFO.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-saffron text-midnight font-bold font-sans text-xs hover:bg-saffron-light transition-colors mt-3 shadow-saffron-glow"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Open WhatsApp Chat</span>
                  </a>
                </div>
              </div>

            </div>
          </div>

          {/* RIGHT: Map View */}
          <div className="lg:col-span-7">
            <div className="bg-midnight-card border border-midnight-border rounded-3xl p-3 shadow-2xl relative overflow-hidden">
              <div className="w-full h-[380px] sm:h-[450px] rounded-2xl overflow-hidden relative bg-midnight">
                <iframe
                  title="Fendi Cafe Sialkot Location Map"
                  src={CAFE_INFO.googleMapsEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0, filter: "invert(90%) hue-rotate(180deg) contrast(1.1)" }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
