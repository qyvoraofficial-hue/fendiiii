import React from "react";

interface FendiLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  showSubtitle?: boolean;
}

export const FendiLogo: React.FC<FendiLogoProps> = ({
  className = "",
  size = "md",
  showSubtitle = true,
}) => {
  const dimensions = {
    sm: "w-10 h-10",
    md: "w-14 h-14",
    lg: "w-20 h-20",
    xl: "w-28 h-28",
  }[size];

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className={`relative flex-shrink-0 ${dimensions}`}>
        <svg
          viewBox="0 0 200 200"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-[0_2px_12px_rgba(227,154,50,0.35)]"
        >
          {/* Glowing Flame Gradient Definition */}
          <defs>
            <linearGradient id="flameGrad" x1="100" y1="20" x2="100" y2="180" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFC264" />
              <stop offset="45%" stopColor="#E39A32" />
              <stop offset="100%" stopColor="#B34B3C" />
            </linearGradient>
            <linearGradient id="goldText" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#FFC264" />
              <stop offset="100%" stopColor="#E39A32" />
            </linearGradient>
          </defs>

          {/* Flame Base Outer Silhouette */}
          <path
            d="M100 22C100 22 120 50 120 70C120 76.5 116.5 83 111 87C125 76 142 90 142 108C142 135 120 152 100 152C80 152 58 135 58 108C58 87 75 76 89 87C83.5 83 80 76.5 80 70C80 50 100 22 100 22Z"
            fill="url(#flameGrad)"
          />

          {/* Inner Flame Spark Highlights */}
          <path
            d="M100 45C100 45 112 65 112 80C112 90 105 97 100 102C95 97 88 90 88 80C88 65 100 45 100 45Z"
            fill="#FFF9F0"
            opacity="0.9"
          />

          {/* Cutout Fork & Knife Symbol */}
          <g fill="#242424">
            {/* Fork Silhouette */}
            <path d="M82 105 L82 128 L86 128 L86 105 C86 100 90 100 90 95 L90 85 L88 85 L88 93 L85 93 L85 85 L83 85 L83 93 L80 93 L80 85 L78 85 L78 95 C78 100 82 100 82 105 Z" />
            {/* Knife Silhouette */}
            <path d="M115 85 C110 92 110 102 110 108 L114 108 L114 128 L118 128 L118 85 Z" />
          </g>

          {/* Outer Curved Text Guide Lines */}
          <path id="textArcTop" d="M 30,100 A 70,70 0 1,1 170,100" fill="none" />

          {/* Est 2020 Badge */}
          <rect x="68" y="160" width="64" height="18" rx="4" fill="#E39A32" />
          <text
            x="100"
            y="173"
            fill="#242424"
            fontSize="10"
            fontWeight="bold"
            letterSpacing="1.5"
            textAnchor="middle"
            fontFamily="sans-serif"
          >
            EST 2020
          </text>
        </svg>
      </div>

      <div>
        <span className="block font-serif text-xl sm:text-2xl font-bold tracking-wider text-warm-ivory uppercase leading-none text-ivory">
          Fendi <span className="text-saffron">Café</span>
        </span>
        {showSubtitle && (
          <span className="block text-[10px] sm:text-xs font-mono tracking-[0.25em] text-ivory-subtle uppercase mt-1">
            Ace of Taste • Sialkot
          </span>
        )}
      </div>
    </div>
  );
};
