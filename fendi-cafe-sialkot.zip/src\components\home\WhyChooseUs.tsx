"use client";

import React from "react";
import { Clock, MapPin, ShieldCheck, MessageSquare } from "lucide-react";

export const WhyChooseUs: React.FC = () => {
  const reasons = [
    {
      icon: Clock,
      title: "Late Night Reliability",
      description: "Operating continuously from 2:00 PM to 2:00 AM daily, serving hot meals straight through the night.",
    },
    {
      icon: MapPin,
      title: "Circular Road Location",
      description: "Located opposite ECHO / PSO Petrol Pump, Kashmiri Mohalla for fast takeaways and hassle-free pickups.",
    },
    {
      icon: ShieldCheck,
      title: "Made Fresh to Order",
      description: "Every burger, shawarma wrap, and wing batch is prepared fresh upon order—never pre-cooked or stored.",
    },
    {
      icon: MessageSquare,
      title: "Direct WhatsApp Order",
      description: "Send your complete order straight to our kitchen via WhatsApp with instant delivery & pickup updates.",
    },
  ];

  return (
    <section className="py-20 bg-midnight relative border-t border-midnight-border">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
          <span className="text-xs font-mono uppercase tracking-widest text-saffron">
            Honest Quality & Service
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-ivory">
            Why Customers Choose Fendi
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reasons.map((reason, idx) => {
            const Icon = reason.icon;
            return (
              <div
                key={idx}
                className="bg-midnight-card border border-midnight-border hover:border-saffron/40 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 rounded-xl bg-saffron/10 border border-saffron/30 flex items-center justify-center text-saffron mb-5">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-serif font-bold text-lg text-ivory mb-2">
                  {reason.title}
                </h3>
                <p className="text-xs text-ivory-muted leading-relaxed font-sans">
                  {reason.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
