"use client";

import React, { useEffect } from "react";
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight } from "lucide-react";
import { useCartStore } from "@/store/useCartStore";

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    closeCart,
    updateQuantity,
    removeItem,
    clearCart,
    getTotalPrice,
    getTotalItems,
    openCheckout,
  } = useCartStore();

  // Lock body scroll when cart is open
  useEffect(() => {
    if (isCartOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
  }, [isCartOpen]);

  // Handle ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeCart();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [closeCart]);

  if (!isCartOpen) return null;

  const totalPrice = getTotalPrice();
  const totalItems = getTotalItems();

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={closeCart}
        className="fixed inset-0 bg-midnight/80 backdrop-blur-md transition-opacity animate-in fade-in duration-300"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-midnight-card border-l border-midnight-border shadow-drawer flex flex-col justify-between animate-in slide-in-from-right duration-300">
          
          {/* Header */}
          <div className="p-6 border-b border-midnight-border flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-saffron" />
              <h2 className="font-serif text-xl font-bold text-ivory">Your Cart</h2>
              <span className="text-xs font-mono text-saffron bg-saffron/10 px-2 py-0.5 rounded-full border border-saffron/20">
                {totalItems} items
              </span>
            </div>

            <button
              onClick={closeCart}
              aria-label="Close cart"
              className="p-2 rounded-xl bg-midnight-elevated text-ivory-subtle hover:text-ivory transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 divide-y divide-midnight-border/50">
            {cart.length > 0 ? (
              cart.map(({ menuItem, quantity }) => {
                const lineTotal = menuItem.price * quantity;

                return (
                  <div key={menuItem.id} className="pt-4 first:pt-0 flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-serif font-bold text-ivory text-sm truncate">
                        {menuItem.name}
                      </h4>
                      <span className="text-xs font-mono text-ivory-subtle block mt-0.5">
                        PKR {menuItem.price.toLocaleString()} × {quantity}
                      </span>
                      <span className="text-xs font-serif font-bold text-saffron block mt-1">
                        PKR {lineTotal.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      {/* Quantity Selector */}
                      <div className="flex items-center border border-midnight-border rounded-lg bg-midnight">
                        <button
                          onClick={() => updateQuantity(menuItem.id, -1)}
                          className="p-1 text-ivory-subtle hover:text-saffron transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 text-xs font-mono font-bold text-ivory">
                          {quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(menuItem.id, 1)}
                          className="p-1 text-ivory-subtle hover:text-saffron transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Remove item button */}
                      <button
                        onClick={() => removeItem(menuItem.id)}
                        className="p-1.5 text-paprika hover:text-paprika-dark transition-colors"
                        title="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="text-center py-16 space-y-3">
                <ShoppingBag className="w-12 h-12 text-ivory-subtle/30 mx-auto" />
                <h3 className="font-serif text-lg font-bold text-ivory">Your cart is empty</h3>
                <p className="text-xs text-ivory-muted max-w-xs mx-auto">
                  Explore our menu to add burgers, shawarmas, or late-night deals.
                </p>
              </div>
            )}
          </div>

          {/* Footer Checkout Bar */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-midnight-border bg-midnight-secondary space-y-4">
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-ivory-muted font-sans">Grand Total:</span>
                <span className="font-serif text-2xl font-bold text-saffron">
                  PKR {totalPrice.toLocaleString()}
                </span>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    if (window.confirm("Are you sure you want to clear your cart?")) {
                      clearCart();
                    }
                  }}
                  className="px-4 py-3 rounded-xl bg-midnight-elevated border border-midnight-border text-paprika hover:bg-paprika/10 text-xs font-mono transition-colors"
                >
                  Clear
                </button>

                <button
                  onClick={openCheckout}
                  className="flex-1 py-3.5 rounded-xl bg-saffron text-midnight font-bold font-sans text-sm hover:bg-saffron-light active:scale-95 transition-all shadow-saffron-glow flex items-center justify-center gap-2"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
