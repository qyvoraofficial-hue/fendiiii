import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

type ThemeMode = "dark" | "light";

interface ThemeStore {
  theme: ThemeMode;
  toggleTheme: () => void;
  setTheme: (theme: ThemeMode) => void;
}

export const useThemeStore = create<ThemeStore>()(
  persist(
    (set, get) => ({
      theme: "dark",
      toggleTheme: () => {
        const nextTheme = get().theme === "dark" ? "light" : "dark";
        set({ theme: nextTheme });
        if (typeof document !== "undefined") {
          const root = document.documentElement;
          root.classList.remove("dark", "light");
          root.classList.add(nextTheme);
        }
      },
      setTheme: (theme: ThemeMode) => {
        set({ theme });
        if (typeof document !== "undefined") {
          const root = document.documentElement;
          root.classList.remove("dark", "light");
          root.classList.add(theme);
        }
      },
    }),
    {
      name: "fendi-cafe-theme",
      storage: createJSONStorage(() => localStorage),
    }
  )
);
