"use client";

import React from "react";
import { Flame, Clock, Heart, Award } from "lucide-react";
import { CAFE_INFO } from "@/data/menu";

export const BrandStory: React.FC = () => {
  return (
    <section id="story" className="py-24 bg-midnight relative border-t border-midnight-border">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* LEFT: Editorial Content */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-saffron/30 bg-saffron/10 text-saffron font-mono text-xs uppercase tracking-widest">
              <Flame className="w-3.5 h-3.5" />
              <span>Established 2020 • Sialkot</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-5xl font-bold text-ivory leading-tight">
              Crafted for Late-Night Cravers & Serious Foodies
            </h2>

            <div className="space-y-4 text-sm sm:text-base text-ivory-muted font-sans leading-relaxed">
              <p>
                Founded in 2020 on Circular Road, Sialkot, <strong className="text-ivory">Fendi Café</strong> was created with a clear mission: to serve uncompromised, flavour-packed comfort food when Sialkot needs it most.
              </p>
              <p>
                Whether it's our signature Thunder Burger with melted cheese, crispy zinger fillets injected with liquid cheese, or authentic Arabic shawarma platters drizzled with secret garlic sauce, every single item is prepared fresh upon order.
              </p>
              <p>
                We operate straight through the night until <strong className="text-saffron">2:00 AM every single day</strong>, giving late-night workers, students, families, and friends a warm spot to satisfy their serious cravings.
              </p>
            </div>

            {/* Core Values / Details Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-midnight-card border border-midnight-border flex items-start gap-3">
                <Clock className="w-5 h-5 text-saffron flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-serif font-bold text-ivory text-sm">Night Owl Hours</h4>
                  <p className="text-xs text-ivory-subtle mt-1">Open 2:00 PM to 2:00 AM Monday through Sunday</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-midnight-card border border-midnight-border flex items-start gap-3">
                <Heart className="w-5 h-5 text-saffron flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-serif font-bold text-ivory text-sm">Fresh Ingredients</h4>
                  <p className="text-xs text-ivory-subtle mt-1">100% fresh chicken, house baked sauces & crisp veggies</p>
                </div>
              </div>
            </div>

          </div>

          {/* RIGHT: Visual Editorial Card */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-md bg-midnight-card border border-midnight-border rounded-3xl p-8 shadow-2xl space-y-6">
              
              <div className="flex items-center justify-between border-b border-midnight-border pb-4">
                <span className="font-mono text-xs text-saffron uppercase tracking-widest">
                  Location Stamp
                </span>
                <span className="font-mono text-xs text-ivory-subtle">
                  Kashmiri Mohalla
                </span>
              </div>

              <div className="space-y-4">
                <h3 className="font-serif text-2xl font-bold text-ivory">
                  Circular Road Landmark
                </h3>
                <p className="text-xs text-ivory-muted leading-relaxed font-sans">
                  Conveniently situated right opposite the ECHO / PSO Petrol Pump on Circular Road, Fendi Café is easy to reach for quick takeaway pickups or fast local delivery.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-midnight-elevated border border-saffron/20 space-y-2">
                <div className="flex items-center justify-between text-xs text-ivory font-mono">
                  <span>Takeaway Service</span>
                  <span className="text-saffron">Fast Pickup</span>
                </div>
                <div className="flex items-center justify-between text-xs text-ivory font-mono">
                  <span>WhatsApp Delivery</span>
                  <span className="text-saffron">Direct Confirmation</span>
                </div>
                <div className="flex items-center justify-between text-xs text-ivory font-mono">
                  <span>Opening Hours</span>
                  <span className="text-saffron">2 PM - 2 AM</span>
                </div>
              </div>

              <div className="text-center pt-2">
                <span className="font-serif text-xs italic text-ivory-subtle">
                  "Ace of Taste — Prepared fresh for serious cravings."
                </span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
