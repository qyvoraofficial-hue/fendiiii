import { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    {
      url: "https://fendicafe.pk",
      lastModified: new Date(),
      changeFrequency: "daily",
      priority: 1,
    },
  ];
}
