"use client";

import React from "react";
import { UtensilsCrossed, ShoppingBag, MessageSquare } from "lucide-react";
import { useCartStore } from "@/store/useCartStore";
import { useIsMounted } from "@/hooks/useIsMounted";
import { CAFE_INFO } from "@/data/menu";

export const MobileStickyBar: React.FC = () => {
  const isMounted = useIsMounted();
  const totalItems = useCartStore((state) => (isMounted ? state.getTotalItems() : 0));
  const openCart = useCartStore((state) => state.openCart);

  const scrollToMenu = () => {
    const el = document.getElementById("menu");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-midnight/95 backdrop-blur-xl border-t border-midnight-border px-4 py-2.5 shadow-2xl">
      <div className="grid grid-cols-3 gap-2">
        
        {/* Menu shortcut */}
        <button
          onClick={scrollToMenu}
          className="flex flex-col items-center justify-center gap-1 py-1 text-ivory-muted hover:text-saffron transition-colors"
        >
          <UtensilsCrossed className="w-5 h-5 text-saffron" />
          <span className="text-[10px] font-mono uppercase tracking-wider">Menu</span>
        </button>

        {/* Cart drawer */}
        <button
          onClick={openCart}
          className="relative flex flex-col items-center justify-center gap-1 py-1 text-ivory-muted hover:text-saffron transition-colors"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5 text-saffron" />
            {isMounted && totalItems > 0 && (
              <span className="absolute -top-1.5 -right-2.5 bg-saffron text-midnight font-bold font-mono text-[9px] w-4 h-4 rounded-full flex items-center justify-center shadow-saffron-glow">
                {totalItems}
              </span>
            )}
          </div>
          <span className="text-[10px] font-mono uppercase tracking-wider">Cart</span>
        </button>

        {/* WhatsApp Direct */}
        <a
          href={CAFE_INFO.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center gap-1 py-1 text-ivory-muted hover:text-saffron transition-colors"
        >
          <MessageSquare className="w-5 h-5 text-saffron" />
          <span className="text-[10px] font-mono uppercase tracking-wider">WhatsApp</span>
        </a>

      </div>
    </div>
  );
};
