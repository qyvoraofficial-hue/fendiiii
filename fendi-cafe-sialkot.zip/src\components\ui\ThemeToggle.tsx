"use client";

import React, { useEffect, useState } from "react";
import { Sun, Moon } from "lucide-react";
import { useThemeStore } from "@/store/useThemeStore";

export const ThemeToggle: React.FC<{ className?: string }> = ({ className = "" }) => {
  const { theme, toggleTheme } = useThemeStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Apply class on initial mount
    const root = document.documentElement;
    root.classList.remove("dark", "light");
    root.classList.add(theme);
  }, [theme]);

  if (!mounted) {
    return (
      <div className={`w-9 h-9 rounded-xl bg-midnight-card border border-midnight-border ${className}`} />
    );
  }

  return (
    <button
      onClick={toggleTheme}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
      className={`p-2 rounded-xl bg-midnight-card border border-midnight-border text-saffron hover:bg-midnight-elevated transition-all active:scale-95 focus:outline-none focus:ring-2 focus:ring-saffron ${className}`}
    >
      {theme === "dark" ? (
        <Sun className="w-5 h-5 transition-transform hover:rotate-45 duration-300" />
      ) : (
        <Moon className="w-5 h-5 transition-transform hover:-rotate-12 duration-300" />
      )}
    </button>
  );
};
