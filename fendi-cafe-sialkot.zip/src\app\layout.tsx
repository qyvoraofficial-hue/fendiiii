import type { Metadata } from "next";
import "./globals.css";
import { CAFE_INFO } from "@/data/menu";

export const metadata: Metadata = {
  title: "Fendi Café Sialkot | Shawarma, Burgers, Pizza & More",
  description:
    "Explore the Fendi Café Sialkot menu for fresh shawarmas, burgers, pizza and loaded favourites. Order takeaway or request delivery through WhatsApp.",
  keywords: [
    "Fendi Café Sialkot",
    "Café in Sialkot",
    "Shawarma in Sialkot",
    "Burgers in Sialkot",
    "Pizza in Sialkot",
    "Food on Circular Road Sialkot",
    "Takeaway in Sialkot",
    "Food delivery in Sialkot",
  ],
  metadataBase: new URL("https://fendicafe.pk"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Fendi Café Sialkot | Ace of Taste",
    description:
      "Sialkot's Late-Night Flavour Spot. Fresh burgers, crispy zinger rolls, loaded fries & Middle Eastern shawarmas open until 2:00 AM.",
    url: "https://fendicafe.pk",
    siteName: "Fendi Café Sialkot",
    images: [
      {
        url: "/images/fendi-menu-page1.jpg",
        width: 1200,
        height: 630,
        alt: "Fendi Café Sialkot Menu",
      },
    ],
    locale: "en_PK",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Fendi Café Sialkot | Shawarma, Burgers & More",
    description:
      "Explore the Fendi Café Sialkot menu for fresh shawarmas, burgers, pizza and loaded favourites. Order takeaway or request delivery through WhatsApp.",
    images: ["/images/fendi-menu-page1.jpg"],
  },
};

// JSON-LD LocalBusiness & Restaurant Schema
const jsonLdData = {
  "@context": "https://schema.org",
  "@type": "Restaurant",
  name: "Fendi Café",
  image: "https://fendicafe.pk/images/fendi-menu-page1.jpg",
  "@id": "https://fendicafe.pk",
  url: "https://fendicafe.pk",
  telephone: CAFE_INFO.phone,
  address: {
    "@type": "PostalAddress",
    streetAddress: "Opposite ECHO Petrol Pump, Circular Road, Kashmiri Mohalla",
    addressLocality: "Sialkot",
    addressRegion: "Punjab",
    postalCode: "51310",
    addressCountry: "PK",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 32.4945,
    longitude: 74.5229,
  },
  openingHoursSpecification: {
    "@type": "OpeningHoursSpecification",
    dayOfWeek: [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday",
    ],
    opens: "14:00",
    closes: "02:00",
  },
  servesCuisine: ["Fast Food", "Middle Eastern", "Burgers", "Shawarma"],
  priceRange: "$$",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdData) }}
        />
      </head>
      <body className="bg-midnight text-ivory antialiased selection:bg-saffron selection:text-midnight min-h-screen flex flex-col">
        {/* WCAG Skip Link */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 z-50 px-4 py-2 bg-saffron text-midnight font-bold rounded-lg"
        >
          Skip to main content
        </a>

        {children}
      </body>
    </html>
  );
}
