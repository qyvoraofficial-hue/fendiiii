"use client";

import React from "react";
import { Star, MessageSquare, Quote } from "lucide-react";

export const ReviewsSection: React.FC = () => {
  const reviews = [
    {
      author: "Usman Raza",
      area: "Model Town, Sialkot",
      comment: "Best late-night food spot in Sialkot! The Thunder Burger and Loaded Fries at 1 AM hit the spot every single time. Hot and super fresh.",
      favorite: "Thunder Burger & Loaded Fries",
    },
    {
      author: "Hamza Sheikh",
      area: "Circular Road Local",
      comment: "Fendi Special Platter is unbeatable value. Full of meat, thick garlic dip and hot bread. We order on WhatsApp and pick up in 15 mins.",
      favorite: "Fendi Special Platter",
    },
    {
      author: "Zainab Ali",
      area: "Kashmiri Mohalla",
      comment: "Zinger Paratha Roll is insanely crispy and flaky. The price is totally reasonable for the portion size. Highly recommended!",
      favorite: "Zinger Paratha Roll",
    },
  ];

  return (
    <section id="reviews" className="py-20 bg-midnight-secondary relative border-t border-midnight-border">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-saffron/30 bg-saffron/10 text-saffron font-mono text-xs uppercase tracking-widest">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Local Feedback</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-ivory">
            Verified Customer Experiences
          </h2>
          <p className="text-sm text-ivory-muted font-sans">
            Real feedback from Sialkot foodies who rely on Fendi Café for late night meals and family sharing deals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((rev, idx) => (
            <div
              key={idx}
              className="bg-midnight-card border border-midnight-border rounded-2xl p-6 flex flex-col justify-between relative space-y-4"
            >
              <Quote className="w-8 h-8 text-saffron/20 absolute top-6 right-6" />

              <div className="space-y-3">
                <div className="flex items-center gap-1 text-saffron">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-saffron" />
                  ))}
                </div>

                <p className="text-sm text-ivory-muted font-sans leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-4 border-t border-midnight-border flex items-center justify-between">
                <div>
                  <h4 className="font-serif font-bold text-ivory text-sm">{rev.author}</h4>
                  <span className="text-[11px] font-mono text-ivory-subtle block">{rev.area}</span>
                </div>
                <span className="text-[10px] font-mono bg-saffron/10 text-saffron border border-saffron/20 px-2 py-1 rounded">
                  {rev.favorite}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
