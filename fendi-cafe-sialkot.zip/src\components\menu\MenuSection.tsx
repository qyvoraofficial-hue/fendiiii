"use client";

import React, { useState, useMemo } from "react";
import { Search, Plus, Minus, Check, Sparkles, Filter, X } from "lucide-react";
import { MENU_CATEGORIES, MENU_ITEMS } from "@/data/menu";
import { CategoryId, MenuItem } from "@/types";
import { useCartStore } from "@/store/useCartStore";
import { useMenuStore } from "@/store/useMenuStore";
import { useIsMounted } from "@/hooks/useIsMounted";

export const MenuSection: React.FC = () => {
  const isMounted = useIsMounted();
  const [activeCategory, setActiveCategory] = useState<CategoryId>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [addedItemIds, setAddedItemIds] = useState<Record<string, boolean>>({});

  const storeItems = useMenuStore((state) => state.items);
  const addItem = useCartStore((state) => state.addItem);

  // Use static fallback during SSR to ensure server HTML === client initial HTML
  const menuItems = isMounted ? storeItems : MENU_ITEMS;

  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      const matchesCategory =
        activeCategory === "all" || item.category === activeCategory;
      const matchesSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.description &&
          item.description.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [menuItems, activeCategory, searchQuery]);

  const handleQuantityChange = (id: string, delta: number) => {
    setQuantities((prev) => {
      const current = prev[id] || 1;
      const updated = current + delta;
      return { ...prev, [id]: updated > 1 ? updated : 1 };
    });
  };

  const handleAddToCart = (item: MenuItem) => {
    const qty = quantities[item.id] || 1;
    addItem(item, qty);

    setAddedItemIds((prev) => ({ ...prev, [item.id]: true }));
    setTimeout(() => {
      setAddedItemIds((prev) => ({ ...prev, [item.id]: false }));
    }, 1500);
  };

  return (
    <section id="menu" className="py-24 bg-midnight-secondary relative">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-saffron/30 bg-saffron/10 text-saffron font-mono text-xs uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Complete Fendi Café Menu</span>
          </div>
          <h2 className="font-serif text-4xl sm:text-5xl font-bold text-ivory">
            Explore Our Menu
          </h2>
          <p className="text-sm sm:text-base text-ivory-muted font-sans">
            Prepared fresh to order with genuine local ingredients and signature seasonings. Select your favourites for Takeaway or WhatsApp Delivery.
          </p>
        </div>

        {/* Search Bar & Category Filter Row */}
        <div className="mb-10 space-y-6">
          
          {/* Search Field */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ivory-subtle" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search burgers, shawarmas, wings, deals..."
              className="w-full bg-midnight-card border border-midnight-border rounded-xl pl-11 pr-10 py-3 text-sm text-ivory placeholder-ivory-subtle focus:outline-none focus:border-saffron focus:ring-1 focus:ring-saffron transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-ivory-subtle hover:text-ivory"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-3 scrollbar-none justify-start lg:justify-center">
            {MENU_CATEGORIES.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id as CategoryId)}
                  className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-sans font-medium whitespace-nowrap transition-all border ${
                    isActive
                      ? "bg-saffron text-midnight border-saffron font-bold shadow-saffron-glow"
                      : "bg-midnight-card border-midnight-border text-ivory-muted hover:text-ivory hover:border-saffron/30"
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

        </div>

        {/* Menu Cards Grid */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item, idx) => {
              const qty = quantities[item.id] || 1;
              const isAdded = !!addedItemIds[item.id];
              const isAccentBorder = item.isPopular || idx % 5 === 0;

              return (
                <div
                  key={item.id}
                  className={`bg-midnight-card rounded-2xl p-6 border flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 ${
                    isAccentBorder
                      ? "border-saffron/40 shadow-card-subtle"
                      : "border-midnight-border hover:border-saffron/30"
                  }`}
                >
                  <div>
                    {/* Item Header */}
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-mono uppercase tracking-wider text-ivory-subtle">
                        {item.category.replace("-", " ")}
                      </span>
                      {item.isPopular && (
                        <span className="text-[10px] font-mono tracking-widest uppercase bg-saffron/15 text-saffron px-2 py-0.5 rounded border border-saffron/30 font-bold">
                          POPULAR
                        </span>
                      )}
                      {item.isSoldOut && (
                        <span className="text-[10px] font-mono tracking-widest uppercase bg-paprika/20 text-paprika px-2 py-0.5 rounded border border-paprika/30">
                          SOLD OUT
                        </span>
                      )}
                    </div>

                    {/* Item Title */}
                    <h3 className="font-serif text-xl font-bold text-ivory mb-2">
                      {item.name}
                    </h3>

                    {/* Description */}
                    {item.description ? (
                      <p className="text-xs text-ivory-muted leading-relaxed font-sans mb-6">
                        {item.description}
                      </p>
                    ) : (
                      <div className="h-6 mb-6" />
                    )}
                  </div>

                  {/* Pricing and Add Controls */}
                  <div className="pt-4 border-t border-midnight-border flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                    <div>
                      <span className="text-[10px] font-mono text-ivory-subtle block uppercase">Exact Price</span>
                      <span className="font-serif text-xl font-bold text-saffron">
                        PKR {item.price.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Quantity Controls */}
                      <div className="flex items-center border border-midnight-border rounded-lg bg-midnight-secondary">
                        <button
                          onClick={() => handleQuantityChange(item.id, -1)}
                          aria-label="Decrease quantity"
                          className="p-1.5 text-ivory-muted hover:text-saffron transition-colors"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2.5 text-xs font-mono font-bold text-ivory">
                          {qty}
                        </span>
                        <button
                          onClick={() => handleQuantityChange(item.id, 1)}
                          aria-label="Increase quantity"
                          className="p-1.5 text-ivory-muted hover:text-saffron transition-colors"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Add Button */}
                      <button
                        onClick={() => handleAddToCart(item)}
                        disabled={item.isSoldOut}
                        className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg font-sans text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                          item.isSoldOut
                            ? "bg-midnight-elevated text-ivory-subtle cursor-not-allowed"
                            : isAdded
                            ? "bg-emerald-500 text-white"
                            : "bg-saffron text-midnight hover:bg-saffron-light active:scale-95 shadow-saffron-glow"
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Added</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 bg-midnight-card border border-midnight-border rounded-2xl max-w-md mx-auto p-8">
            <Filter className="w-10 h-10 text-saffron/50 mx-auto mb-4" />
            <h3 className="font-serif text-xl font-bold text-ivory mb-2">
              No menu items found
            </h3>
            <p className="text-xs text-ivory-muted mb-6">
              We couldn't find any dishes matching "{searchQuery}".
            </p>
            <button
              onClick={() => {
                setSearchQuery("");
                setActiveCategory("all");
              }}
              className="px-5 py-2.5 rounded-xl bg-saffron text-midnight text-xs font-bold font-sans hover:bg-saffron-light transition-colors"
            >
              Reset Search & Filters
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
