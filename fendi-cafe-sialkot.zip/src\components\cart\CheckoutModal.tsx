"use client";

import React, { useState } from "react";
import { X, ShoppingBag, Truck, MapPin, Phone, User, Clock, MessageSquare, AlertCircle } from "lucide-react";
import { useCartStore } from "@/store/useCartStore";
import { generateWhatsAppOrderUrl } from "@/utils/whatsapp";

export const CheckoutModal: React.FC = () => {
  const {
    cart,
    isCheckoutOpen,
    closeCheckout,
    orderType,
    setOrderType,
    takeawayDetails,
    setTakeawayDetails,
    deliveryDetails,
    setDeliveryDetails,
    getTotalPrice,
  } = useCartStore();

  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!isCheckoutOpen) return null;

  const totalPrice = getTotalPrice();

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (orderType === "delivery") {
      if (!deliveryDetails.name.trim()) newErrors.name = "Customer name is required";
      if (!deliveryDetails.phone.trim()) newErrors.phone = "Phone number is required";
      if (!deliveryDetails.address.trim()) newErrors.address = "Complete address is required";
      if (!deliveryDetails.area.trim()) newErrors.area = "Area name is required";
      if (!deliveryDetails.landmark.trim()) newErrors.landmark = "Landmark is required";
    } else {
      if (!takeawayDetails.name.trim()) newErrors.name = "Customer name is required";
      if (!takeawayDetails.phone.trim()) newErrors.phone = "Phone number is required";
      if (!takeawayDetails.pickupTime.trim()) newErrors.pickupTime = "Preferred pickup time is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePlaceWhatsAppOrder = () => {
    if (!validateForm()) return;

    const whatsappUrl = generateWhatsAppOrderUrl(
      cart,
      orderType,
      takeawayDetails,
      deliveryDetails,
      totalPrice
    );

    window.open(whatsappUrl, "_blank");
    closeCheckout();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-4 sm:p-6 flex items-center justify-center">
      {/* Backdrop */}
      <div
        onClick={closeCheckout}
        className="fixed inset-0 bg-midnight/85 backdrop-blur-md transition-opacity animate-in fade-in duration-300"
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-lg bg-midnight-card border border-midnight-border rounded-3xl shadow-2xl overflow-hidden z-10 animate-in zoom-in-95 duration-200 my-8">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-midnight-border flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono uppercase tracking-widest text-saffron">
              WhatsApp Direct Order
            </span>
            <h2 className="font-serif text-2xl font-bold text-ivory">Checkout Details</h2>
          </div>
          <button
            onClick={closeCheckout}
            className="p-2 rounded-xl bg-midnight-elevated text-ivory-subtle hover:text-ivory transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Order Type Selector Tabs */}
          <div className="space-y-2">
            <label className="text-xs font-mono text-ivory-subtle uppercase">Select Order Type</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setOrderType("delivery")}
                className={`py-3 px-4 rounded-xl text-xs font-bold font-sans flex items-center justify-center gap-2 border transition-all ${
                  orderType === "delivery"
                    ? "bg-saffron text-midnight border-saffron shadow-saffron-glow"
                    : "bg-midnight-elevated border-midnight-border text-ivory-muted hover:text-ivory"
                }`}
              >
                <Truck className="w-4 h-4" />
                <span>Delivery</span>
              </button>

              <button
                type="button"
                onClick={() => setOrderType("takeaway")}
                className={`py-3 px-4 rounded-xl text-xs font-bold font-sans flex items-center justify-center gap-2 border transition-all ${
                  orderType === "takeaway"
                    ? "bg-saffron text-midnight border-saffron shadow-saffron-glow"
                    : "bg-midnight-elevated border-midnight-border text-ivory-muted hover:text-ivory"
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Takeaway / Pickup</span>
              </button>
            </div>
          </div>

          {/* Form Fields based on Order Type */}
          {orderType === "delivery" ? (
            <div className="space-y-4">
              
              {/* Delivery Name */}
              <div>
                <label className="block text-xs font-sans text-ivory mb-1">Customer Name *</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ivory-subtle" />
                  <input
                    type="text"
                    value={deliveryDetails.name}
                    onChange={(e) => setDeliveryDetails({ name: e.target.value })}
                    placeholder="e.g. Ali Ahmed"
                    className="w-full bg-midnight border border-midnight-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                </div>
                {errors.name && <p className="text-[11px] text-paprika mt-1">{errors.name}</p>}
              </div>

              {/* Delivery Phone */}
              <div>
                <label className="block text-xs font-sans text-ivory mb-1">Phone Number *</label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ivory-subtle" />
                  <input
                    type="tel"
                    value={deliveryDetails.phone}
                    onChange={(e) => setDeliveryDetails({ phone: e.target.value })}
                    placeholder="e.g. 0300 1234567"
                    className="w-full bg-midnight border border-midnight-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                </div>
                {errors.phone && <p className="text-[11px] text-paprika mt-1">{errors.phone}</p>}
              </div>

              {/* Delivery Address */}
              <div>
                <label className="block text-xs font-sans text-ivory mb-1">Complete Address *</label>
                <div className="relative">
                  <MapPin className="absolute left-3.5 top-3 w-4 h-4 text-ivory-subtle" />
                  <textarea
                    rows={2}
                    value={deliveryDetails.address}
                    onChange={(e) => setDeliveryDetails({ address: e.target.value })}
                    placeholder="House / Street / Block detail..."
                    className="w-full bg-midnight border border-midnight-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                </div>
                {errors.address && <p className="text-[11px] text-paprika mt-1">{errors.address}</p>}
              </div>

              {/* Area & Landmark Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-sans text-ivory mb-1">Area *</label>
                  <input
                    type="text"
                    value={deliveryDetails.area}
                    onChange={(e) => setDeliveryDetails({ area: e.target.value })}
                    placeholder="e.g. Kashmiri Mohalla / Model Town"
                    className="w-full bg-midnight border border-midnight-border rounded-xl px-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                  {errors.area && <p className="text-[11px] text-paprika mt-1">{errors.area}</p>}
                </div>

                <div>
                  <label className="block text-xs font-sans text-ivory mb-1">Landmark *</label>
                  <input
                    type="text"
                    value={deliveryDetails.landmark}
                    onChange={(e) => setDeliveryDetails({ landmark: e.target.value })}
                    placeholder="e.g. Near PSO Pump"
                    className="w-full bg-midnight border border-midnight-border rounded-xl px-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                  {errors.landmark && <p className="text-[11px] text-paprika mt-1">{errors.landmark}</p>}
                </div>
              </div>

              {/* Delivery Note */}
              <div>
                <label className="block text-xs font-sans text-ivory mb-1">Order Note (Optional)</label>
                <input
                  type="text"
                  value={deliveryDetails.note}
                  onChange={(e) => setDeliveryDetails({ note: e.target.value })}
                  placeholder="e.g. Make it extra spicy, less garlic..."
                  className="w-full bg-midnight border border-midnight-border rounded-xl px-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                />
              </div>

              {/* Transparent Delivery Disclaimer */}
              <div className="p-3 bg-saffron/10 border border-saffron/30 rounded-xl flex items-start gap-2 text-xs text-ivory-muted">
                <AlertCircle className="w-4 h-4 text-saffron flex-shrink-0 mt-0.5" />
                <p>
                  <strong className="text-saffron">Delivery Notice:</strong> Delivery availability and charges will be confirmed on WhatsApp.
                </p>
              </div>

            </div>
          ) : (
            <div className="space-y-4">
              
              {/* Takeaway Name */}
              <div>
                <label className="block text-xs font-sans text-ivory mb-1">Customer Name *</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ivory-subtle" />
                  <input
                    type="text"
                    value={takeawayDetails.name}
                    onChange={(e) => setTakeawayDetails({ name: e.target.value })}
                    placeholder="e.g. Usman Raza"
                    className="w-full bg-midnight border border-midnight-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                </div>
                {errors.name && <p className="text-[11px] text-paprika mt-1">{errors.name}</p>}
              </div>

              {/* Takeaway Phone */}
              <div>
                <label className="block text-xs font-sans text-ivory mb-1">Phone Number *</label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ivory-subtle" />
                  <input
                    type="tel"
                    value={takeawayDetails.phone}
                    onChange={(e) => setTakeawayDetails({ phone: e.target.value })}
                    placeholder="e.g. 0334 6599111"
                    className="w-full bg-midnight border border-midnight-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                </div>
                {errors.phone && <p className="text-[11px] text-paprika mt-1">{errors.phone}</p>}
              </div>

              {/* Preferred Pickup Time */}
              <div>
                <label className="block text-xs font-sans text-ivory mb-1">Preferred Pickup Time *</label>
                <div className="relative">
                  <Clock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ivory-subtle" />
                  <input
                    type="text"
                    value={takeawayDetails.pickupTime}
                    onChange={(e) => setTakeawayDetails({ pickupTime: e.target.value })}
                    placeholder="e.g. In 20 minutes / 10:30 PM"
                    className="w-full bg-midnight border border-midnight-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                </div>
                {errors.pickupTime && <p className="text-[11px] text-paprika mt-1">{errors.pickupTime}</p>}
              </div>

              {/* Takeaway Note */}
              <div>
                <label className="block text-xs font-sans text-ivory mb-1">Order Note (Optional)</label>
                <input
                  type="text"
                  value={takeawayDetails.note}
                  onChange={(e) => setTakeawayDetails({ note: e.target.value })}
                  placeholder="e.g. Pack extra ketchup..."
                  className="w-full bg-midnight border border-midnight-border rounded-xl px-4 py-2.5 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                />
              </div>

            </div>
          )}

          {/* Summary line */}
          <div className="p-4 rounded-xl bg-midnight border border-midnight-border flex items-center justify-between">
            <span className="text-xs text-ivory-muted">Grand Total ({cart.length} items):</span>
            <span className="font-serif text-xl font-bold text-saffron">
              PKR {totalPrice.toLocaleString()}
            </span>
          </div>

        </div>

        {/* Modal Footer Action */}
        <div className="p-6 border-t border-midnight-border bg-midnight-secondary flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={closeCheckout}
            className="px-5 py-3 rounded-xl bg-midnight-elevated text-ivory-muted hover:text-ivory text-xs font-bold font-sans transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handlePlaceWhatsAppOrder}
            className="px-6 py-3.5 rounded-xl bg-saffron text-midnight font-bold font-sans text-xs hover:bg-saffron-light active:scale-95 transition-all shadow-saffron-glow flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Send Order via WhatsApp</span>
          </button>
        </div>

      </div>
    </div>
  );
};
