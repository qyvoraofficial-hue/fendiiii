"use client";

import React from "react";
import { Sparkles } from "lucide-react";

const TRUST_STATEMENTS = [
  "OPEN LATE: 2:00 PM – 2:00 AM DAILY",
  "CIRCULAR ROAD, KASHMIRI MOHALLA, SIALKOT",
  "TAKEAWAY & FAST HOME DELIVERY VIA WHATSAPP",
  "FRESHLY PREPARED CRISPY ZINGER & BEEF BURGERS",
  "AUTHENTIC MIDDLE EASTERN ARABIC SHAWARMA",
  "FENDI CAFÉ — ACE OF TASTE EST. 2020",
];

export const TrustTicker: React.FC = () => {
  return (
    <section className="py-4 bg-midnight-secondary border-y border-midnight-border overflow-hidden select-none">
      <div className="flex gap-8 whitespace-nowrap group hover:[animation-play-state:paused] animate-marquee">
        {[...TRUST_STATEMENTS, ...TRUST_STATEMENTS, ...TRUST_STATEMENTS].map((text, idx) => (
          <div key={idx} className="inline-flex items-center gap-4 text-xs sm:text-sm font-mono tracking-widest uppercase text-ivory-muted">
            <span className="text-saffron font-bold font-serif">•</span>
            <span>{text}</span>
            <Sparkles className="w-3.5 h-3.5 text-saffron/70" />
          </div>
        ))}
      </div>
    </section>
  );
};
