"use client";

import React, { useState } from "react";
import { X, Plus, Trash2, Edit3, Lock, ShieldCheck, Check, Search, RotateCcw, Flame, AlertCircle } from "lucide-react";
import { useMenuStore } from "@/store/useMenuStore";
import { MENU_CATEGORIES } from "@/data/menu";
import { CategoryId, MenuItem } from "@/types";

export const AdminPanelModal: React.FC = () => {
  const {
    items,
    isAdminOpen,
    closeAdmin,
    addItem,
    updateItemPrice,
    updateItem,
    deleteItem,
    togglePopular,
    toggleSoldOut,
    resetToDefaultMenu,
  } = useMenuStore();

  const [passcode, setPasscode] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authError, setAuthError] = useState("");

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  // State for Add New Item modal inside Admin
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newItemName, setNewItemName] = useState("");
  const [newItemCategory, setNewItemCategory] = useState<CategoryId>("burgers");
  const [newItemPrice, setNewItemPrice] = useState<number>(500);
  const [newItemDesc, setNewItemDesc] = useState("");
  const [newItemPopular, setNewItemPopular] = useState(false);

  // Edit item state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingPrice, setEditingPrice] = useState<number>(0);

  if (!isAdminOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Default Cafe PIN: 2020 (or any password typed)
    if (passcode === "2020" || passcode.toLowerCase() === "admin") {
      setIsAuthenticated(true);
      setAuthError("");
    } else {
      setAuthError("Invalid Passcode. Enter '2020' to unlock.");
    }
  };

  const handleSaveNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    addItem({
      name: newItemName.toUpperCase(),
      category: newItemCategory,
      price: Number(newItemPrice),
      description: newItemDesc,
      isPopular: newItemPopular,
    });

    // Reset form
    setNewItemName("");
    setNewItemDesc("");
    setNewItemPrice(500);
    setIsAddingNew(false);
  };

  const handleStartEditPrice = (item: MenuItem) => {
    setEditingId(item.id);
    setEditingPrice(item.price);
  };

  const handleSaveEditPrice = (id: string) => {
    updateItemPrice(id, Number(editingPrice));
    setEditingId(null);
  };

  const filteredItems = items.filter((item) => {
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-4 sm:p-6 flex items-center justify-center">
      {/* Backdrop */}
      <div
        onClick={closeAdmin}
        className="fixed inset-0 bg-midnight/85 backdrop-blur-md transition-opacity animate-in fade-in duration-300"
      />

      <div className="relative w-full max-w-4xl bg-midnight-card border border-midnight-border rounded-3xl shadow-2xl overflow-hidden z-10 animate-in zoom-in-95 duration-200 my-8">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-midnight-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-saffron/10 border border-saffron/30 flex items-center justify-center text-saffron">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-saffron">
                Owner Dashboard
              </span>
              <h2 className="font-serif text-2xl font-bold text-ivory">Menu & Price Manager</h2>
            </div>
          </div>

          <button
            onClick={closeAdmin}
            className="p-2 rounded-xl bg-midnight-elevated text-ivory-subtle hover:text-ivory transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Passcode Authentication Screen */}
        {!isAuthenticated ? (
          <form onSubmit={handleLogin} className="p-8 max-w-md mx-auto space-y-6 text-center">
            <div className="w-14 h-14 rounded-full bg-saffron/10 border border-saffron/30 flex items-center justify-center text-saffron mx-auto">
              <Lock className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-serif text-xl font-bold text-ivory">Manager Authentication</h3>
              <p className="text-xs text-ivory-muted mt-1 font-sans">
                Enter your café manager PIN to change prices or add menu items.
              </p>
            </div>

            <div className="space-y-2">
              <input
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="Enter PIN (Default: 2020)"
                className="w-full bg-midnight border border-midnight-border rounded-xl px-4 py-3 text-center text-lg font-mono text-saffron placeholder-ivory-subtle focus:border-saffron focus:outline-none"
              />
              {authError && <p className="text-xs text-paprika font-mono">{authError}</p>}
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-saffron text-midnight font-bold font-sans text-sm hover:bg-saffron-light active:scale-95 transition-all shadow-saffron-glow"
            >
              Unlock Dashboard
            </button>
          </form>
        ) : (
          /* Authenticated Dashboard View */
          <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
            
            {/* Top Dashboard Actions */}
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-midnight-border pb-4">
              
              {/* Search & Category filter */}
              <div className="flex flex-wrap items-center gap-3 flex-1">
                <div className="relative min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ivory-subtle" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search menu..."
                    className="w-full bg-midnight border border-midnight-border rounded-xl pl-9 pr-3 py-2 text-xs text-ivory placeholder-ivory-subtle focus:border-saffron focus:outline-none"
                  />
                </div>

                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-midnight border border-midnight-border rounded-xl px-3 py-2 text-xs text-ivory focus:border-saffron focus:outline-none"
                >
                  <option value="all">All Categories</option>
                  {MENU_CATEGORIES.filter((c) => c.id !== "all").map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsAddingNew(!isAddingNew)}
                  className="px-4 py-2 rounded-xl bg-saffron text-midnight font-bold text-xs font-sans hover:bg-saffron-light transition-colors flex items-center gap-1.5 shadow-saffron-glow"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add New Item</span>
                </button>

                <button
                  onClick={() => {
                    if (confirm("Reset menu to factory default items and original menu prices?")) {
                      resetToDefaultMenu();
                    }
                  }}
                  className="p-2 rounded-xl bg-midnight-elevated border border-midnight-border text-ivory-subtle hover:text-paprika transition-colors"
                  title="Reset Menu"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

            </div>

            {/* Add New Item Form Drawer */}
            {isAddingNew && (
              <form onSubmit={handleSaveNewItem} className="bg-midnight border border-saffron/40 rounded-2xl p-6 space-y-4 animate-in slide-in-from-top duration-200">
                <div className="flex items-center justify-between border-b border-midnight-border pb-3">
                  <h3 className="font-serif font-bold text-ivory text-base">Add New Dish to Menu</h3>
                  <button type="button" onClick={() => setIsAddingNew(false)} className="text-ivory-subtle hover:text-ivory">
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs text-ivory mb-1 font-mono">Item Name *</label>
                    <input
                      type="text"
                      required
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                      placeholder="e.g. CHEESE BURGER"
                      className="w-full bg-midnight-card border border-midnight-border rounded-xl px-3 py-2 text-xs text-ivory focus:border-saffron focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-ivory mb-1 font-mono">Category *</label>
                    <select
                      value={newItemCategory}
                      onChange={(e) => setNewItemCategory(e.target.value as CategoryId)}
                      className="w-full bg-midnight-card border border-midnight-border rounded-xl px-3 py-2 text-xs text-ivory focus:border-saffron focus:outline-none"
                    >
                      {MENU_CATEGORIES.filter((c) => c.id !== "all").map((cat) => (
                        <option key={cat.id} value={cat.id}>
                          {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-ivory mb-1 font-mono">Price (PKR) *</label>
                    <input
                      type="number"
                      required
                      value={newItemPrice}
                      onChange={(e) => setNewItemPrice(Number(e.target.value))}
                      placeholder="450"
                      className="w-full bg-midnight-card border border-midnight-border rounded-xl px-3 py-2 text-xs text-ivory focus:border-saffron focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-ivory mb-1 font-mono">Description (Optional)</label>
                  <input
                    type="text"
                    value={newItemDesc}
                    onChange={(e) => setNewItemDesc(e.target.value)}
                    placeholder="Brief ingredients or dish summary..."
                    className="w-full bg-midnight-card border border-midnight-border rounded-xl px-3 py-2 text-xs text-ivory focus:border-saffron focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-ivory">
                    <input
                      type="checkbox"
                      checked={newItemPopular}
                      onChange={(e) => setNewItemPopular(e.target.checked)}
                      className="rounded border-midnight-border text-saffron focus:ring-saffron"
                    />
                    <span>Mark as Popular Badge</span>
                  </label>

                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-saffron text-midnight font-bold font-sans text-xs hover:bg-saffron-light transition-colors"
                  >
                    Save New Dish
                  </button>
                </div>
              </form>
            )}

            {/* Menu Items Table */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono text-ivory-subtle px-2">
                <span>Showing {filteredItems.length} menu items</span>
                <span>Click price to edit instantly</span>
              </div>

              <div className="divide-y divide-midnight-border border border-midnight-border rounded-2xl overflow-hidden bg-midnight-card">
                {filteredItems.map((item) => {
                  const isEditing = editingId === item.id;

                  return (
                    <div
                      key={item.id}
                      className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-midnight-elevated/40 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-serif font-bold text-ivory text-sm truncate">
                            {item.name}
                          </h4>
                          <span className="text-[10px] font-mono uppercase bg-midnight px-2 py-0.5 rounded text-ivory-subtle border border-midnight-border">
                            {item.category}
                          </span>
                          {item.isPopular && (
                            <span className="text-[10px] font-mono text-saffron bg-saffron/10 px-1.5 py-0.5 rounded border border-saffron/20">
                              Popular
                            </span>
                          )}
                          {item.isSoldOut && (
                            <span className="text-[10px] font-mono text-paprika bg-paprika/10 px-1.5 py-0.5 rounded border border-paprika/20">
                              Sold Out
                            </span>
                          )}
                        </div>
                        {item.description && (
                          <p className="text-xs text-ivory-muted truncate">{item.description}</p>
                        )}
                      </div>

                      {/* Price & Action Controls */}
                      <div className="flex items-center gap-3 self-end sm:self-center">
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-ivory-subtle font-mono">PKR</span>
                            <input
                              type="number"
                              value={editingPrice}
                              onChange={(e) => setEditingPrice(Number(e.target.value))}
                              className="w-24 bg-midnight border border-saffron rounded-lg px-2 py-1 text-xs text-saffron font-bold font-mono focus:outline-none"
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveEditPrice(item.id)}
                              className="p-1.5 rounded-lg bg-saffron text-midnight hover:bg-saffron-light"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleStartEditPrice(item)}
                            className="group flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-midnight border border-midnight-border hover:border-saffron/50 transition-colors"
                          >
                            <span className="text-xs font-mono font-bold text-saffron">
                              PKR {item.price.toLocaleString()}
                            </span>
                            <Edit3 className="w-3 h-3 text-ivory-subtle group-hover:text-saffron transition-colors" />
                          </button>
                        )}

                        {/* Toggle Sold Out */}
                        <button
                          onClick={() => toggleSoldOut(item.id)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-mono transition-colors border ${
                            item.isSoldOut
                              ? "bg-paprika/20 text-paprika border-paprika/40"
                              : "bg-midnight border-midnight-border text-ivory-subtle hover:text-ivory"
                          }`}
                        >
                          {item.isSoldOut ? "Available" : "Sold Out"}
                        </button>

                        {/* Delete Item */}
                        <button
                          onClick={() => {
                            if (confirm(`Delete "${item.name}" from menu?`)) {
                              deleteItem(item.id);
                            }
                          }}
                          className="p-1.5 text-ivory-subtle hover:text-paprika transition-colors"
                          title="Delete item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
