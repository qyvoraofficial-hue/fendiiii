import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { MenuItem, CategoryId } from "@/types";
import { MENU_ITEMS } from "@/data/menu";

interface MenuStore {
  items: MenuItem[];
  isAdminOpen: boolean;
  
  // Actions
  openAdmin: () => void;
  closeAdmin: () => void;
  toggleAdmin: () => void;

  addItem: (newItem: Omit<MenuItem, "id">) => void;
  updateItemPrice: (id: string, price: number) => void;
  updateItem: (id: string, updated: Partial<MenuItem>) => void;
  deleteItem: (id: string) => void;
  togglePopular: (id: string) => void;
  toggleSoldOut: (id: string) => void;
  resetToDefaultMenu: () => void;
}

export const useMenuStore = create<MenuStore>()(
  persist(
    (set, get) => ({
      items: MENU_ITEMS,
      isAdminOpen: false,

      openAdmin: () => set({ isAdminOpen: true }),
      closeAdmin: () => set({ isAdminOpen: false }),
      toggleAdmin: () => set((state) => ({ isAdminOpen: !state.isAdminOpen })),

      addItem: (newItemData) => {
        const newId = `custom-${Date.now()}`;
        const item: MenuItem = {
          ...newItemData,
          id: newId,
        };
        set({ items: [item, ...get().items] });
      },

      updateItemPrice: (id: string, price: number) => {
        set({
          items: get().items.map((item) =>
            item.id === id ? { ...item, price: Math.max(0, price) } : item
          ),
        });
      },

      updateItem: (id: string, updated: Partial<MenuItem>) => {
        set({
          items: get().items.map((item) =>
            item.id === id ? { ...item, ...updated } : item
          ),
        });
      },

      deleteItem: (id: string) => {
        set({
          items: get().items.filter((item) => item.id !== id),
        });
      },

      togglePopular: (id: string) => {
        set({
          items: get().items.map((item) =>
            item.id === id ? { ...item, isPopular: !item.isPopular } : item
          ),
        });
      },

      toggleSoldOut: (id: string) => {
        set({
          items: get().items.map((item) =>
            item.id === id ? { ...item, isSoldOut: !item.isSoldOut } : item
          ),
        });
      },

      resetToDefaultMenu: () => {
        set({ items: MENU_ITEMS });
      },
    }),
    {
      name: "fendi-cafe-dynamic-menu-v1",
      storage: createJSONStorage(() => localStorage),
    }
  )
);
