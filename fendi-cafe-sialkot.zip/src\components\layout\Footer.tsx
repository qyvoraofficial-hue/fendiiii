"use client";

import React from "react";
import { ShieldCheck } from "lucide-react";
import { FendiLogo } from "@/components/ui/FendiLogo";
import { CAFE_INFO } from "@/data/menu";
import { useMenuStore } from "@/store/useMenuStore";

export const Footer: React.FC = () => {
  const openAdmin = useMenuStore((state) => state.openAdmin);

  const scrollToSection = (id: string) => {
    if (id === "hero") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-midnight-secondary border-t border-midnight-border pt-16 pb-24 md:pb-12 text-ivory font-sans">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <FendiLogo size="lg" />
            <p className="text-xs text-ivory-muted max-w-sm leading-relaxed">
              Fendi Café — Ace of Taste. Sialkot's favourite spot for fresh burgers, zinger rolls, Middle Eastern shawarmas, and late-night cravings.
            </p>
            <div className="text-xs font-mono text-saffron">
              Open Daily: {CAFE_INFO.openingHours}
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-sm uppercase text-ivory tracking-wider">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs text-ivory-muted font-sans">
              <li>
                <button onClick={() => scrollToSection("hero")} className="hover:text-saffron transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("menu")} className="hover:text-saffron transition-colors">
                  Full Menu
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("story")} className="hover:text-saffron transition-colors">
                  Our Story
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("reviews")} className="hover:text-saffron transition-colors">
                  Customer Reviews
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("location")} className="hover:text-saffron transition-colors">
                  Location & Hours
                </button>
              </li>
            </ul>
          </div>

          {/* Location */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-sm uppercase text-ivory tracking-wider">
              Location
            </h4>
            <div className="space-y-1.5 text-xs text-ivory-muted">
              <p className="text-ivory font-medium">Fendi Café Sialkot</p>
              <p>{CAFE_INFO.fullAddress}</p>
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(CAFE_INFO.googleMapsQuery)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block text-saffron font-mono text-[11px] hover:underline mt-1"
              >
                Google Maps directions →
              </a>
            </div>
          </div>

          {/* Direct Contact & Admin Panel Trigger */}
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-sm uppercase text-ivory tracking-wider">
              Direct Contact
            </h4>
            <div className="space-y-1.5 text-xs text-ivory-muted">
              <p>Mobile / WhatsApp:</p>
              <a href={CAFE_INFO.whatsappUrl} target="_blank" rel="noopener noreferrer" className="text-saffron font-mono block hover:underline">
                {CAFE_INFO.phone}
              </a>
              <p className="pt-1">Landline: {CAFE_INFO.secondaryPhone}</p>

              <button
                onClick={openAdmin}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-saffron/10 border border-saffron/30 text-saffron text-xs font-mono hover:bg-saffron/20 transition-colors mt-3"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Manage Prices / Menu</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Copyright Strip */}
        <div className="pt-8 border-t border-midnight-border/50 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-ivory-subtle font-mono">
          <p>© {new Date().getFullYear()} Fendi Café Sialkot. All rights reserved.</p>
          <p>
            Bespoke Digital Experience by{" "}
            <span className="text-saffron font-bold">Qyvora Studio</span>
          </p>
        </div>

      </div>
    </footer>
  );
};
