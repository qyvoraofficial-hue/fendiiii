import { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Fendi Café Sialkot",
    short_name: "Fendi Café",
    description: "Sialkot's Late-Night Flavour Spot — Fresh Burgers, Shawarma, Loaded Fries & Deals",
    start_url: "/",
    display: "standalone",
    background_color: "#242424",
    theme_color: "#E39A32",
    icons: [
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
  };
}
