import { CartItem, OrderType, TakeawayDetails, DeliveryDetails } from "@/types";
import { CAFE_INFO } from "@/data/menu";

export function generateWhatsAppOrderUrl(
  cart: CartItem[],
  orderType: OrderType,
  takeawayDetails: TakeawayDetails,
  deliveryDetails: DeliveryDetails,
  totalPrice: number
): string {
  if (cart.length === 0) {
    return `${CAFE_INFO.whatsappUrl}?text=${encodeURIComponent(
      "Assalam-o-Alaikum Fendi Cafe! I would like to place an order."
    )}`;
  }

  const lines: string[] = [];

  lines.push("Assalam-o-Alaikum Fendi Cafe!\n");
  lines.push("I would like to place an order.\n");

  const customerName = orderType === "delivery" ? deliveryDetails.name : takeawayDetails.name;
  const customerPhone = orderType === "delivery" ? deliveryDetails.phone : takeawayDetails.phone;

  lines.push(`Order Type: ${orderType === "delivery" ? "Delivery" : "Takeaway / Pickup"}`);
  lines.push(`Customer: ${customerName}`);
  lines.push(`Phone: ${customerPhone}\n`);

  lines.push("Order:");
  cart.forEach((item, index) => {
    const lineTotal = item.menuItem.price * item.quantity;
    lines.push(
      `${index + 1}. ${item.menuItem.name} × ${item.quantity} — PKR ${lineTotal.toLocaleString()}`
    );
  });

  lines.push(`\nGrand Total: PKR ${totalPrice.toLocaleString()}\n`);

  if (orderType === "delivery") {
    lines.push("Delivery Address:");
    lines.push(deliveryDetails.address);
    if (deliveryDetails.area) lines.push(`Area: ${deliveryDetails.area}`);
    if (deliveryDetails.landmark) lines.push(`Landmark: ${deliveryDetails.landmark}`);
    if (deliveryDetails.note) lines.push(`Note: ${deliveryDetails.note}`);
  } else {
    lines.push(`Preferred Pickup Time: ${takeawayDetails.pickupTime}`);
    if (takeawayDetails.note) lines.push(`Note: ${takeawayDetails.note}`);
  }

  lines.push(
    "\nPlease confirm the order, delivery availability and charges. Thank you."
  );

  const fullMessage = lines.join("\n");
  const encoded = encodeURIComponent(fullMessage);
  return `${CAFE_INFO.whatsappUrl}?text=${encoded}`;
}
