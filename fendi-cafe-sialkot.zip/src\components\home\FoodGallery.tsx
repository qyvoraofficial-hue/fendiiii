"use client";

import React, { useState } from "react";
import Image from "next/image";
import { ZoomIn, X, Camera, Sparkles } from "lucide-react";

export const FoodGallery: React.FC = () => {
  const [activeImage, setActiveImage] = useState<string | null>(null);

  const galleryItems = [
    {
      id: "page1",
      title: "Menu & Dish Showcase — Page 1",
      subtitle: "Appetizers, Burgers, Shawarma & Wraps",
      src: "/images/fendi-menu-page1.jpg",
    },
    {
      id: "page2",
      title: "Burger Deals & Brand Cover — Page 2",
      subtitle: "Combo Deals & Official Logo Seal",
      src: "/images/fendi-menu-page2.jpg",
    },
  ];

  return (
    <section className="py-20 bg-midnight-secondary relative border-t border-midnight-border">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-saffron/30 bg-saffron/10 text-saffron font-mono text-xs uppercase tracking-widest">
            <Camera className="w-3.5 h-3.5" />
            <span>Official Menu Photography</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-ivory">
            Verified Menu Gallery
          </h2>
          <p className="text-sm text-ivory-muted font-sans">
            Inspect our original menu sheets and food photography. Click any card to inspect full high-resolution details.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {galleryItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setActiveImage(item.src)}
              className="group relative bg-midnight-card border border-midnight-border hover:border-saffron/50 rounded-2xl overflow-hidden cursor-pointer shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <div className="relative h-[340px] sm:h-[400px] w-full overflow-hidden bg-midnight">
                <Image
                  src={item.src}
                  alt={item.title}
                  fill
                  className="object-contain group-hover:scale-105 transition-transform duration-500 p-2"
                />
                <div className="absolute inset-0 bg-midnight/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="bg-saffron text-midnight p-3 rounded-full shadow-saffron-glow">
                    <ZoomIn className="w-6 h-6" />
                  </div>
                </div>
              </div>

              <div className="p-5 border-t border-midnight-border bg-midnight-card flex items-center justify-between">
                <div>
                  <h3 className="font-serif font-bold text-ivory text-base group-hover:text-saffron transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-ivory-muted font-mono mt-0.5">{item.subtitle}</p>
                </div>
                <span className="text-xs font-mono text-saffron font-bold">Click to view →</span>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Overlay */}
      {activeImage && (
        <div
          onClick={() => setActiveImage(null)}
          className="fixed inset-0 z-50 bg-midnight/95 backdrop-blur-xl p-4 sm:p-8 flex items-center justify-center animate-in fade-in duration-200"
        >
          <button
            onClick={() => setActiveImage(null)}
            className="absolute top-6 right-6 p-3 rounded-full bg-midnight-card border border-midnight-border text-ivory hover:text-saffron transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="relative w-full max-w-5xl h-[85vh] flex items-center justify-center p-2">
            <Image
              src={activeImage}
              alt="Expanded menu photograph"
              fill
              className="object-contain"
            />
          </div>
        </div>
      )}
    </section>
  );
};
