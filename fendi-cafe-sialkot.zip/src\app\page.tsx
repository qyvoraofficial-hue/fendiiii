import { AnnouncementStrip } from "@/components/layout/AnnouncementStrip";
import { Navbar } from "@/components/layout/Navbar";
import { ExplodedBurgerHero } from "@/components/hero/ExplodedBurgerHero";
import { TrustTicker } from "@/components/home/TrustTicker";
import { SignatureDishes } from "@/components/home/SignatureDishes";
import { MenuSection } from "@/components/menu/MenuSection";
import { BrandStory } from "@/components/home/BrandStory";
import { FoodGallery } from "@/components/home/FoodGallery";
import { WhyChooseUs } from "@/components/home/WhyChooseUs";
import { ReviewsSection } from "@/components/home/ReviewsSection";
import { HowToOrderSection } from "@/components/home/HowToOrderSection";
import { LocationHoursSection } from "@/components/home/LocationHoursSection";
import { WhatsAppCtaBanner } from "@/components/home/WhatsAppCtaBanner";
import { Footer } from "@/components/layout/Footer";
import { CartDrawer } from "@/components/cart/CartDrawer";
import { CheckoutModal } from "@/components/cart/CheckoutModal";
import { AdminPanelModal } from "@/components/admin/AdminPanelModal";
import { MobileStickyBar } from "@/components/layout/MobileStickyBar";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-midnight text-ivory overflow-x-hidden">
      {/* 1. Top Announcement Bar */}
      <AnnouncementStrip />

      {/* 2. Floating Navbar */}
      <Navbar />

      {/* Main Page Sections */}
      <main id="main-content" className="flex-1">
        {/* 3. Exploded Burger Hero */}
        <ExplodedBurgerHero />

        {/* 4. Trust Statement Ticker */}
        <TrustTicker />

        {/* 5. Signature Dishes Showcase */}
        <SignatureDishes />

        {/* 6. Filterable Menu */}
        <MenuSection />

        {/* 7. Brand Story */}
        <BrandStory />

        {/* 8. Food Gallery */}
        <FoodGallery />

        {/* 9. Why Choose Us */}
        <WhyChooseUs />

        {/* 10. Verified Reviews */}
        <ReviewsSection />

        {/* 11. How to Order Explanation */}
        <HowToOrderSection />

        {/* 12. Location & Hours */}
        <LocationHoursSection />

        {/* 13. WhatsApp CTA Banner */}
        <WhatsAppCtaBanner />
      </main>

      {/* 14. Premium Footer */}
      <Footer />

      {/* 15. Cart Slide-Over Drawer */}
      <CartDrawer />

      {/* 16. Checkout Modal Sheet */}
      <CheckoutModal />

      {/* 17. Owner Admin Panel Modal */}
      <AdminPanelModal />

      {/* 18. Mobile Sticky Action Bar */}
      <MobileStickyBar />
    </div>
  );
}
