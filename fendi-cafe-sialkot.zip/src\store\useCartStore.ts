import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { CartItem, MenuItem, OrderType, TakeawayDetails, DeliveryDetails } from "@/types";

interface CartStore {
  cart: CartItem[];
  isCartOpen: boolean;
  isCheckoutOpen: boolean;
  orderType: OrderType;
  takeawayDetails: TakeawayDetails;
  deliveryDetails: DeliveryDetails;

  // Actions
  addItem: (item: MenuItem, quantity?: number) => void;
  removeItem: (itemId: string) => void;
  updateQuantity: (itemId: string, delta: number) => void;
  clearCart: () => void;
  
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;

  openCheckout: () => void;
  closeCheckout: () => void;

  setOrderType: (type: OrderType) => void;
  setTakeawayDetails: (details: Partial<TakeawayDetails>) => void;
  setDeliveryDetails: (details: Partial<DeliveryDetails>) => void;

  // Getters
  getTotalItems: () => number;
  getTotalPrice: () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      cart: [],
      isCartOpen: false,
      isCheckoutOpen: false,
      orderType: "delivery",
      takeawayDetails: {
        name: "",
        phone: "",
        pickupTime: "As soon as possible",
        note: "",
      },
      deliveryDetails: {
        name: "",
        phone: "",
        address: "",
        area: "",
        landmark: "",
        note: "",
      },

      addItem: (item: MenuItem, quantity = 1) => {
        const currentCart = get().cart;
        const existingIndex = currentCart.findIndex((i) => i.menuItem.id === item.id);

        if (existingIndex > -1) {
          const updated = [...currentCart];
          updated[existingIndex].quantity += quantity;
          set({ cart: updated });
        } else {
          set({ cart: [...currentCart, { menuItem: item, quantity }] });
        }
      },

      removeItem: (itemId: string) => {
        set({ cart: get().cart.filter((i) => i.menuItem.id !== itemId) });
      },

      updateQuantity: (itemId: string, delta: number) => {
        const currentCart = get().cart;
        const updated = currentCart
          .map((item) => {
            if (item.menuItem.id === itemId) {
              const newQty = item.quantity + delta;
              return newQty > 0 ? { ...item, quantity: newQty } : null;
            }
            return item;
          })
          .filter(Boolean) as CartItem[];

        set({ cart: updated });
      },

      clearCart: () => set({ cart: [] }),

      openCart: () => set({ isCartOpen: true }),
      closeCart: () => set({ isCartOpen: false }),
      toggleCart: () => set((state) => ({ isCartOpen: !state.isCartOpen })),

      openCheckout: () => set({ isCheckoutOpen: true, isCartOpen: false }),
      closeCheckout: () => set({ isCheckoutOpen: false }),

      setOrderType: (type: OrderType) => set({ orderType: type }),
      setTakeawayDetails: (details) =>
        set((state) => ({
          takeawayDetails: { ...state.takeawayDetails, ...details },
        })),
      setDeliveryDetails: (details) =>
        set((state) => ({
          deliveryDetails: { ...state.deliveryDetails, ...details },
        })),

      getTotalItems: () => {
        return get().cart.reduce((sum, item) => sum + item.quantity, 0);
      },

      getTotalPrice: () => {
        return get().cart.reduce(
          (sum, item) => sum + item.menuItem.price * item.quantity,
          0
        );
      },
    }),
    {
      name: "fendi-cafe-cart-v1",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        cart: state.cart,
        orderType: state.orderType,
        takeawayDetails: state.takeawayDetails,
        deliveryDetails: state.deliveryDetails,
      }),
    }
  )
);
