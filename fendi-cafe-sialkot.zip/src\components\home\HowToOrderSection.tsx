"use client";

import React from "react";
import { ShoppingBag, FileText, Send, CheckCircle2 } from "lucide-react";

export const HowToOrderSection: React.FC = () => {
  const steps = [
    {
      num: "01",
      icon: ShoppingBag,
      title: "Build Your Order",
      desc: "Select your favourite burgers, shawarma wraps, appetizers or deals directly from our menu.",
    },
    {
      num: "02",
      icon: FileText,
      title: "Select Pickup or Delivery",
      desc: "Provide your name, phone number, preferred pickup time or Sialkot delivery address & landmark.",
    },
    {
      num: "03",
      icon: Send,
      title: "Instant WhatsApp Checkout",
      desc: "Your formatted order opens directly in WhatsApp to +92 334 6599111 for instant kitchen confirmation.",
    },
  ];

  return (
    <section className="py-20 bg-midnight relative border-t border-midnight-border">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
          <span className="text-xs font-mono uppercase tracking-widest text-saffron">
            Simple & Transparent Process
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-ivory">
            How Ordering Works
          </h2>
          <p className="text-sm text-ivory-muted font-sans">
            No complex signups or payment gateway hassles. Order directly in seconds.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={idx}
                className="bg-midnight-card border border-midnight-border rounded-2xl p-8 relative flex flex-col justify-between hover:border-saffron/40 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-serif font-bold text-3xl text-saffron/40">
                      {step.num}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-saffron/10 border border-saffron/30 flex items-center justify-center text-saffron">
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>

                  <h3 className="font-serif font-bold text-xl text-ivory mb-3">
                    {step.title}
                  </h3>
                  <p className="text-xs text-ivory-muted leading-relaxed font-sans">
                    {step.desc}
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-midnight-border flex items-center gap-2 text-xs font-mono text-saffron">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>No login required</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Delivery Note Box */}
        <div className="mt-10 max-w-2xl mx-auto bg-midnight-secondary border border-saffron/30 rounded-xl p-4 text-center">
          <p className="text-xs sm:text-sm text-ivory-muted font-sans">
            <strong className="text-saffron">Delivery Notice:</strong> Delivery availability and exact delivery charges will be confirmed directly on WhatsApp upon order submission.
          </p>
        </div>

      </div>
    </section>
  );
};
